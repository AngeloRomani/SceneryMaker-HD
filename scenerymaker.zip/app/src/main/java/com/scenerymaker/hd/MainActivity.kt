package com.scenerymaker.hd

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.SatelliteAlt
import androidx.compose.material.icons.filled.Terrain
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private const val MAX_TME_BYTES = 200L * 1024L * 1024L

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SceneryMakerApp() }
    }
}

@Composable
private fun SceneryMakerApp() {
    val bg = Color(0xFF0B1220)
    val panel = Color(0xFF151F31)
    val accent = Color(0xFF57D6C7)
    var selectedName by remember { mutableStateOf("Nessun file selezionato") }
    var message by remember { mutableStateOf("Seleziona un file TME per verificarne la dimensione.") }

    val picker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            selectedName = uri.lastPathSegment ?: "File selezionato"
            message = "File selezionato. La verifica completa della dimensione verrà eseguita durante l'esportazione."
        }
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = accent,
            background = bg,
            surface = panel,
            onBackground = Color(0xFFEAF2FF),
            onSurface = Color(0xFFEAF2FF)
        )
    ) {
        Surface(modifier = Modifier.fillMaxSize(), color = bg) {
            Column(
                modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(shape = RoundedCornerShape(16.dp), color = Color(0xFF183A45)) {
                        Icon(Icons.Default.SatelliteAlt, null, tint = accent, modifier = Modifier.padding(13.dp).size(28.dp))
                    }
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text("SCENERY MAKER", fontSize = 12.sp, color = accent, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                        Text("HD", fontSize = 27.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
                    }
                    Spacer(Modifier.weight(1f))
                    Surface(color = Color(0xFF17352F), shape = RoundedCornerShape(50)) {
                        Text("ANDROID", color = accent, modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Box(
                    modifier = Modifier.fillMaxWidth().height(190.dp)
                        .background(Brush.linearGradient(listOf(Color(0xFF12313D), Color(0xFF17243B))), RoundedCornerShape(24.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Icon(Icons.Default.Terrain, null, tint = accent, modifier = Modifier.size(48.dp))
                        Text("Satellite terrain workspace", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                        Text("Immagini pure • senza etichette • non ibride", color = Color(0xFFB5C6D8), fontSize = 12.sp)
                        Text("Motore mappa da configurare", color = accent, fontSize = 11.sp)
                    }
                }

                Text("PROGETTO SCENARIO", color = Color(0xFF9DB0C6), fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                Card(colors = CardDefaults.cardColors(containerColor = panel), shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Area geografica", color = Color.White, fontWeight = FontWeight.Bold)
                        Text("La mappa e la selezione dell'area verranno collegate dopo aver scelto una fonte satellitare con licenza per uso offline.", color = Color(0xFFB5C6D8), fontSize = 13.sp)
                        OutlinedButton(onClick = { message = "La selezione geografica sarà attivata nel passaggio successivo." }, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Default.SatelliteAlt, null)
                            Spacer(Modifier.width(8.dp))
                            Text("Configura mappa satellitare")
                        }
                    }
                }

                Card(colors = CardDefaults.cardColors(containerColor = panel), shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Esportazione TME", color = Color.White, fontWeight = FontWeight.Bold)
                        Text("Limite massimo previsto: 200 MB", color = accent, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        Text(selectedName, color = Color(0xFFB5C6D8), fontSize = 12.sp)
                        Button(
                            onClick = { picker.launch(arrayOf("*/*")) },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Icon(Icons.Default.FolderOpen, null)
                            Spacer(Modifier.width(8.dp))
                            Text("Seleziona file TME")
                        }
                        Text(message, color = Color(0xFF9DB0C6), fontSize = 12.sp)
                    }
                }
                Text("Versione iniziale • Il generatore TME Aerofly non è ancora implementato.", color = Color(0xFF71849B), fontSize = 11.sp)
            }
        }
    }
}
