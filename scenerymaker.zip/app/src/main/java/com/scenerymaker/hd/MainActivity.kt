package com.scenerymaker.hd

import android.annotation.SuppressLint
import android.content.ContentValues
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.ComponentActivity
import java.io.OutputStream

class MainActivity : ComponentActivity() {
    private lateinit var webView: WebView
    private var output: OutputStream? = null
    private var pendingUri: android.net.Uri? = null
    private var pendingBytes: Long = 0
    private var writtenBytes: Long = 0

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.settings.allowContentAccess = true
        webView.settings.mediaPlaybackRequiresUserGesture = true
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = WebViewClient()
        webView.addJavascriptInterface(TmeBridge(), "AndroidTme")
        setContentView(webView)
        webView.loadUrl("file:///android_asset/www/index.html")
    }

    private inner class TmeBridge {
        @JavascriptInterface
        fun beginSave(filename: String, size: Long) {
            try {
                if (size <= 0 || size > 1024L * 1024L * 1024L) throw IllegalArgumentException("TME oltre 1 GB")
                synchronized(this@MainActivity) {
                    output?.close()
                    output = null
                    pendingUri?.let { contentResolver.delete(it, null, null) }
                    val safeName = filename.substringAfterLast('/').replace(Regex("[^A-Za-z0-9._-]"), "_")
                    val values = ContentValues().apply {
                        put(MediaStore.MediaColumns.DISPLAY_NAME, if (safeName.endsWith(".tme")) safeName else "$safeName.tme")
                        put(MediaStore.MediaColumns.MIME_TYPE, "application/octet-stream")
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                            put(MediaStore.MediaColumns.RELATIVE_PATH, "Download/SceneryMakerHD")
                            put(MediaStore.MediaColumns.IS_PENDING, 1)
                        }
                    }
                    val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
                        MediaStore.Downloads.EXTERNAL_CONTENT_URI
                    else MediaStore.Files.getContentUri("external")
                    pendingUri = contentResolver.insert(collection, values)
                        ?: throw IllegalStateException("Impossibile creare il file in Download")
                    output = contentResolver.openOutputStream(pendingUri!!, "w")
                        ?: throw IllegalStateException("Impossibile aprire il file")
                    pendingBytes = size
                    writtenBytes = 0
                }
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this@MainActivity, "Errore salvataggio: ${e.message}", Toast.LENGTH_LONG).show() }
                throw RuntimeException(e)
            }
        }

        @JavascriptInterface
        fun appendChunk(base64: String) {
            synchronized(this@MainActivity) {
                val bytes = Base64.decode(base64, Base64.DEFAULT)
                if (writtenBytes + bytes.size > pendingBytes || writtenBytes + bytes.size > 1024L * 1024L * 1024L) {
                    throw IllegalStateException("Superato limite file TME")
                }
                output?.write(bytes) ?: throw IllegalStateException("Esportazione non inizializzata")
                writtenBytes += bytes.size
            }
        }

        @JavascriptInterface
        fun finishSave() {
            synchronized(this@MainActivity) {
                if (writtenBytes != pendingBytes) throw IllegalStateException("Dimensione file incompleta")
                output?.flush()
                output?.close()
                output = null
                val uri = pendingUri ?: throw IllegalStateException("File non trovato")
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    val values = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
                    contentResolver.update(uri, values, null, null)
                }
                pendingUri = null
                runOnUiThread {
                    Toast.makeText(this@MainActivity, "TME salvato in Download/SceneryMakerHD", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    override fun onDestroy() {
        try { output?.close() } catch (_: Exception) {}
        super.onDestroy()
    }
}
