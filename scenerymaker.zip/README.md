# Scenery Maker HD — integrazione motore originale

Questa build incorpora `assets/www/index.html` estratto dal pacchetto APK fornito, mantenendo il motore JavaScript originale FSG `.tme` (ETC2, texture 2048x2048) e lo avvia in Android WebView.

## Modifiche
- Wrapper Android WebView.
- Selettore di sole fonti aerial/satellite: Bing Aerial, Esri World Imagery, MapTiler Satellite.
- Rimosse le opzioni Hybrid, Road, OSM e cartografia non satellitare.
- Bing Aerial è il livello iniziale.
- MapTiler richiede una propria API key.
- Salvataggio nativo in `Download/SceneryMakerHD`.
- Controllo dimensione TME: massimo 200 MiB.
- Streaming a blocchi dalla WebView verso MediaStore.

## Limiti e licenze
- Il motore originale produce texture ETC2 da 2048x2048 (2K). La modalità 4K non è implementata: non viene simulata tramite upscaling.
- Bing/Esri/MapTiler possono imporre limiti contrattuali a caching, download massivo e creazione di pacchetti offline. Verificare le condizioni del proprio account/contratto prima dell'esportazione. L'app non aggira chiavi API o restrizioni.
- Tailwind, Leaflet, JSZip e Font Awesome sono caricati dalle CDN già indicate nel file originale: la prima apertura richiede internet.
- Il motore originale e i suoi algoritmi sono stati incorporati come riferimento; serve testare il risultato TME su Aerofly FS Android e verificare eventuali differenze rispetto al pacchetto atteso dal simulatore.
