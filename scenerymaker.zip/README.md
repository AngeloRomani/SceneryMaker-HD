# AerialScenery Maker HD

Android WebView app for creating Aerofly FSG `.tme` scenery packages from user-selected satellite imagery.

## Features
- Bing Aerial Satellite and Esri World Imagery only.
- User-defined map area; all regional scenery presets removed.
- 2K (2048 x 2048) and 4K (4096 x 4096) ETC2 texture output.
- Export size hard limit: 200 MiB.
- Saves generated `.tme` files to `Download/SceneryMakerHD`.
- English interface, updated app name and launcher icon.
- No in-app GitHub button.

## Build
With Android SDK installed and Gradle 8.9:

```bash
gradle --no-daemon assembleDebug
```

The debug APK is generated at `app/build/outputs/apk/debug/app-debug.apk`.

## Imagery terms
Bing and Esri imagery are displayed with provider attribution. Availability of tile access, caching, bulk downloading and offline export is subject to each provider's current terms and licensing. Users must ensure their use is authorized.

## Important
The 4K option uses a 4096 x 4096 ETC2 texture and a single encoding worker to reduce peak memory use. Large areas can exceed the 200 MiB package limit; the exporter rejects oversized packages.
