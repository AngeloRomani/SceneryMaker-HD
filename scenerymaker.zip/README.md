# SceneryMaker HD – progetto Android

Questa versione contiene il progetto Android con `MainActivity` basata su `ComponentActivity` e la dipendenza AndroidX Activity aggiunta in `app/build.gradle.kts`.

## Build
Con Android SDK installato e Gradle 8.9:

```bash
gradle --no-daemon assembleDebug
```

L'APK debug viene generato in `app/build/outputs/apk/debug/app-debug.apk`.

## Nota importante sul motore TME
Il progetto include l'interfaccia WebView e il ponte Android per esportare un file `.tme` in Download, con controllo massimo di 200 MiB. Questo intervento corregge la dipendenza AndroidX che causava gli errori `Unresolved reference activity` / `ComponentActivity`.

Non certifica però che il generatore produca un file Aerofly `.tme` valido e completo: per verificarlo e implementare la generazione reale occorre confrontare il formato con il progetto/archivio originale che genera correttamente lo scenario. Le fonti cartografiche devono inoltre essere abilitate solo nel rispetto delle rispettive licenze e condizioni d'uso.
