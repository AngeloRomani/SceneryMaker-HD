# AerialScenery Maker HD — v4.0.0

Android WebView application for creating Aerofly FS TME scenery packages.

- Bing Aerial Satellite and Esri World Imagery
- Texture output: HD 1024x1024, 2K 2048x2048, 4K 4096x4096
- Maximum TME export size: 1 GiB (1024 MiB)
- Downloads saved to Download/SceneryMakerHD
- Professional Aurora navy/cyan interface and refreshed adaptive launcher icon

Important: the 1 GiB limit is a file-size ceiling, not a guarantee that every device can hold a 1 GiB in-memory JSZip blob. Large 4K exports require sufficient device RAM and storage. Provider terms, attribution and usage limits apply to imagery.
