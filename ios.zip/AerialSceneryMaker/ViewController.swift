import UIKit
import WebKit
import UniformTypeIdentifiers

final class ViewController: UIViewController, WKScriptMessageHandler, UIDocumentPickerDelegate {
    private var webView: WKWebView!
    private var exportURL: URL?
    private var exportHandle: FileHandle?
    private var expectedBytes: Int64 = 0
    private var writtenBytes: Int64 = 0

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(red: 5/255, green: 7/255, blue: 5/255, alpha: 1)

        let content = WKUserContentController()
        content.add(self, name: "tme")
        let config = WKWebViewConfiguration()
        config.userContentController = content
        config.allowsInlineMediaPlayback = true

        webView = WKWebView(frame: .zero, configuration: config)
        webView.translatesAutoresizingMaskIntoConstraints = false
        webView.isOpaque = false
        webView.backgroundColor = view.backgroundColor
        webView.scrollView.contentInsetAdjustmentBehavior = .never
        view.addSubview(webView)
        NSLayoutConstraint.activate([
            webView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            webView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            webView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            webView.trailingAnchor.constraint(equalTo: view.trailingAnchor)
        ])

        if let page = Bundle.main.url(forResource: "index", withExtension: "html", subdirectory: "Web") {
            webView.loadFileURL(page, allowingReadAccessTo: page.deletingLastPathComponent())
        }
    }

    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        guard let body = message.body as? [String: Any], let action = body["action"] as? String else { return }
        DispatchQueue.main.async {
            do {
                switch action {
                case "begin":
                    try self.beginExport(filename: body["filename"] as? String ?? "scenery.tme",
                                         size: body["size"] as? Int64 ?? 0)
                case "chunk":
                    try self.appendExportChunk(base64: body["data"] as? String ?? "")
                case "finish":
                    try self.finishExport()
                default: break
                }
            } catch {
                self.showError(error.localizedDescription)
                self.cleanupExport()
            }
        }
    }

    private func beginExport(filename: String, size: Int64) throws {
        guard size > 0, size <= 1_073_741_824 else {
            throw NSError(domain: "AerialScenery", code: 1,
                          userInfo: [NSLocalizedDescriptionKey: "The TME file must be between 1 byte and 1 GB."])
        }
        cleanupExport()
        let safe = URL(fileURLWithPath: filename).lastPathComponent
        let name = safe.lowercased().hasSuffix(".tme") ? safe : safe + ".tme"
        let url = FileManager.default.temporaryDirectory.appendingPathComponent(name)
        FileManager.default.createFile(atPath: url.path, contents: nil)
        exportURL = url
        exportHandle = try FileHandle(forWritingTo: url)
        expectedBytes = size
        writtenBytes = 0
    }

    private func appendExportChunk(base64: String) throws {
        guard let handle = exportHandle, let data = Data(base64Encoded: base64) else {
            throw NSError(domain: "AerialScenery", code: 2,
                          userInfo: [NSLocalizedDescriptionKey: "Invalid export data."])
        }
        writtenBytes += Int64(data.count)
        guard writtenBytes <= expectedBytes, writtenBytes <= 1_073_741_824 else {
            throw NSError(domain: "AerialScenery", code: 3,
                          userInfo: [NSLocalizedDescriptionKey: "The export exceeded the 1 GB limit."])
        }
        try handle.write(contentsOf: data)
    }

    private func finishExport() throws {
        guard writtenBytes == expectedBytes, let handle = exportHandle, let url = exportURL else {
            throw NSError(domain: "AerialScenery", code: 4,
                          userInfo: [NSLocalizedDescriptionKey: "The exported file is incomplete."])
        }
        try handle.close()
        exportHandle = nil
        let picker = UIDocumentPickerViewController(forExporting: [url], asCopy: true)
        picker.delegate = self
        picker.shouldShowFileExtensions = true
        present(picker, animated: true)
        exportURL = nil
    }

    private func cleanupExport() {
        try? exportHandle?.close()
        exportHandle = nil
        if let url = exportURL { try? FileManager.default.removeItem(at: url) }
        exportURL = nil
        expectedBytes = 0
        writtenBytes = 0
    }

    private func showError(_ text: String) {
        let alert = UIAlertController(title: "Export failed", message: text, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }

    deinit {
        webView?.configuration.userContentController.removeScriptMessageHandler(forName: "tme")
        try? exportHandle?.close()
    }
}
