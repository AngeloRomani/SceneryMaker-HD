# AerialScenery Maker HD — iOS

This folder adds an iOS companion target while reusing the shared HTML/JavaScript scenery UI.

## Build
GitHub Actions workflow: `.github/workflows/build-ios.yml`

The workflow builds an **unsigned** device IPA on a macOS runner. It is useful for validating the iOS build and producing the app package, but it is not directly installable on an iPhone until signed with an Apple Development / Distribution certificate and provisioning profile.

## Install / distribution
For personal device installation, configure Apple signing credentials and a provisioning profile, then add an `xcodebuild archive` + `-exportArchive` step. TestFlight/App Store distribution requires Apple Developer Program membership and App Store Connect setup.

## iOS behavior differences
- The TME export uses the iOS Files document export sheet so the user chooses where to save the `.tme`.
- Android-style floating-app Picture-in-Picture is not available for arbitrary app UI on iOS. The PiP button explains this limitation; exports must remain in the foreground unless the app is later redesigned around an eligible media PiP use case.
- Very large 1 GB exports are constrained by device memory, available storage, and iOS app lifecycle limits; validate on target devices.
